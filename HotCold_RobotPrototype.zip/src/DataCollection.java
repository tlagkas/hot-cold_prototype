import java.util.ArrayList;

public class DataCollection {
	
	private ArrayList<Data> sampleCollection;

	public DataCollection(ArrayList<Data> collection){
		sampleCollection = new ArrayList<Data>();
		for(Data d : collection){
			sampleCollection.add(new Data(d));
		}
	}
	
	public ArrayList<Data> getSampleCollection() {
		return sampleCollection;
	}
	
	public void sortBySignal(boolean ascending){
		ArrayList<Data> in = sampleCollection;
		ArrayList<Data> out = new ArrayList<Data>();
		int pos;
		if(ascending){
			while(!in.isEmpty()){
				Data temp = in.get(0);
				pos = 0;
				for(Data d1:in){
					if(d1.getSignal()<temp.getSignal()){
						temp = d1;
						pos = in.indexOf(d1);
					}
				}
				out.add(temp);
				in.remove(pos);
			}
		}else{
			while(!in.isEmpty()){
				Data temp = in.get(0);
				pos = 0;
				for(Data d1:in){
					if(d1.getSignal()>temp.getSignal()){
						temp = d1;
						pos = in.indexOf(d1);
					}
				}
				out.add(temp);
				in.remove(pos);
			}			
		}
		sampleCollection = out;
	}
	
	public int size(){
		return sampleCollection.size();
	}
	
	public void sortByDate(boolean ascending){
		ArrayList<Data> in = sampleCollection;
		ArrayList<Data> out = new ArrayList<Data>();
		int pos;
		if(ascending){
			while(!in.isEmpty()){
				Data temp = in.get(0);
				pos = 0;
				for(Data d1:in){
					if(d1.getTimeStamp().before(temp.getTimeStamp())){
						temp = d1;
						pos = in.indexOf(d1);
					}
				}
				out.add(temp);
				in.remove(pos);
			}
		}else{
			while(!in.isEmpty()){
				Data temp = in.get(0);
				pos = 0;
				for(Data d1:in){
					if(d1.getTimeStamp().after(temp.getTimeStamp())){
						temp = d1;
						pos = in.indexOf(d1);
					}
				}
				out.add(temp);
				in.remove(pos);
			}			
		}
		sampleCollection = out;
	}
	
	public String toString(){
		String s= new String();
		for(Data d: sampleCollection){
			s+=d.toString();
			s+="\n";
		}
		return s;
	}
	

}