import java.util.Random;

import lejos.nxt.Sound;
import lejos.robotics.subsumption.Behavior;

public class RotateRandomly implements Behavior {

	private boolean suppress = false;
	private NXTRpi robot;
	
	public RotateRandomly(NXTRpi robot) {
		super();
		this.robot = robot;
	}

	@Override
	public boolean takeControl() {
		return !robot.isDirectionOK();
	}

	@Override
	public void action() {
		robot.setMoveType(MovementType.RANDOM_TURN);
		// ROTATE TO A NEW RANDOM DIRECTION AND ANGLE
		Random rand = new Random();
		int max = 180;
		int min = 135;
		int direction;
		
		/*
		if(rand.nextBoolean()) direction=1;
		else direction=-1;
		
		
		direction = -robot.getRotationDirection(); // turn the other way
		robot.setRotationDirection(direction);
		
		int randomNum = rand.nextInt((max - min) + 1) + min;
		*/
		
		// Start: fixed rotation
		direction = 1;
		int randomNum = NXTRpi.rotationAngle;
		// End: fixed rotation
		
		System.out.println("Rotating "+direction*randomNum);
		Sound.beep();
		robot.getPilot().rotate(direction*randomNum);
		robot.setDirectionOK(true);
	}

	@Override
	public void suppress() {
		suppress = true;
	}

}
