import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;

public class SensorTimeRSSI {

	public SensorTimeRSSI(String file_path) {
		RSSI = 0;
		timeDate = new Date();
		ENCODING = StandardCharsets.US_ASCII;
		filePath = new String(file_path);
		dataString = new String("");
		path = Paths.get(filePath);
		System.out.println(filePath);
	}

	private int RSSI;
	private Date timeDate;
	private Charset ENCODING;  
	private String filePath;
	private String dataString;  
	private Path path;
	
	public int getRSSI() {
		return RSSI;
	}

	public void setRSSI(int rSSI) {
		RSSI = rSSI;
	}

	public Date getTimeDate() {
		return timeDate;
	}

	public void setTimeDate(Date timeDate) {
		this.timeDate = timeDate;
	}
	
	public Charset getEncoding() {
		return ENCODING;
	}
	
	public void setEncoding(Charset ENCODING) {
		this.ENCODING = ENCODING;
	}
	
	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public void update()  throws IOException, ParseException, StringIndexOutOfBoundsException {
		int timeStampIndex = 0;
		int rssiIndex = 0;
		try (Scanner scanner =  new Scanner(path, ENCODING.name())){
		     dataString = new String("");  
			 while (scanner.hasNextLine()){
		        dataString += scanner.nextLine() + " ";
		      }      
		      scanner.close();
		      timeStampIndex = dataString.indexOf("Datetime");
		      timeStampIndex += 12;
		      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
		      // DEBUG System.out.println(dataString.substring(timeStampIndex-1, timeStampIndex+22));
		      timeDate = simpleDateFormat.parse(dataString.substring(timeStampIndex-1, timeStampIndex+22));
		      rssiIndex = dataString.indexOf("RSSI")+5;
		      // DEBUG System.out.println(dataString.substring(rssiIndex+1, dataString.indexOf(",", rssiIndex)));
		      RSSI = Integer.parseInt(dataString.substring(rssiIndex+1, dataString.indexOf(",", rssiIndex)));
		} catch (IOException ioe) {
			System.out.println("Cannot update from index.php: " + ioe.getLocalizedMessage());
			//System.out.println(timeStampIndex);
			//System.out.println(rssiIndex);
			//this.update();
		} catch (ParseException pe) {
			System.out.println("Cannot update from index.php: " + pe.getLocalizedMessage());
			//System.out.println(timeStampIndex);
			//System.out.println(rssiIndex);
			//this.update();
		} catch (StringIndexOutOfBoundsException se) {
			System.out.println("Cannot update from index.php: " + se.getLocalizedMessage());
			//System.out.println(timeStampIndex);
			//System.out.println(rssiIndex);
			//this.update();
		}
	}
	
	

}
