import java.util.Date;

public class Data{

	private int signal;
	private Date timeStamp;
	private MovementType moveType;
	
	public Data(int signal, Date timeStamp, MovementType moveType) {
		this.signal = signal;
		this.timeStamp = timeStamp;
		this.moveType = moveType;
	}
	
	public Data(Data d){
		this.signal = d.getSignal();
		this.timeStamp = d.getTimeStamp();
		this.moveType = d.getMoveType();
	}

	public int getSignal() {
		return signal;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}	
	
	public MovementType getMoveType() {
		return moveType;
	}	
	
	public String toString(){
		return "[ "+ timeStamp.toString()+" RSSI: "+signal+" MT: "+moveType+" ]";
	}
}

