
public enum MovementType {
	INIT, DRIVE_FRW,  RANDOM_TURN, TOWARDS_IR, TURN_TO_IR, STOP, AVOID
}
