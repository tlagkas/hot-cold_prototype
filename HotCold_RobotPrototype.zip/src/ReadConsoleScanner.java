import java.util.Scanner;

public class ReadConsoleScanner
  extends Thread
{
  private NXTRpi robot;
  
  public ReadConsoleScanner(NXTRpi r)
  {
    this.robot = r;
  }
  
  public void run()
  {
    String exitString = "q";
    Scanner scanIn = new Scanner(System.in);
    while (!exitString.equals(scanIn.nextLine()))
    {
      System.out.println("IN");
      Thread.yield();
    }
    scanIn.close();
    this.robot.exitProgram();
  }
}
