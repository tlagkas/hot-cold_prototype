import java.util.ArrayList;

import lejos.nxt.Sound;

public class SampleAnalyser
  extends Thread
{
  private DataCollection samplesRecieved;
  private ArrayList<Data> memory;
  private boolean suspended;
  NXTRpi robot;
  private boolean exit;
  
  SampleAnalyser(NXTRpi robo)
  {
    this.robot = robo;
    this.memory = new ArrayList();
    this.suspended = true;
    this.exit = false;
  }
  
  public void run()
  {
    while (!this.exit) {
      try
      {
        synchronized (this)
        {
          while (this.suspended) {
            wait();
          }
          process(this.samplesRecieved);
          
          this.suspended = true;
        }
      }
      catch (InterruptedException e)
      {
        System.out.println("ex SampleAnaliser line 33");
      }
    }
  }
  
  public void process(DataCollection samples)
  {
    samples.sortBySignal(true);
    if (samples.size() % 2 != 0)
    {
      Data currentMedian = new Data((Data)samples.getSampleCollection().get((samples.size() - 1) / 2));
      this.robot.updateHistory(currentMedian);
      
      this.memory.add(currentMedian);
    }
    else
    {
      Data currentMedian = new Data((((Data)samples.getSampleCollection().get(samples.size() / 2)).getSignal() + ((Data)samples.getSampleCollection().get(samples.size() / 2 - 1)).getSignal()) / 2, ((Data)samples.getSampleCollection().get(samples.size() / 2 - 1)).getTimeStamp(), ((Data)samples.getSampleCollection().get(samples.size() / 2 - 1)).getMoveType());
      this.robot.updateHistory(currentMedian);
      
      this.memory.add(currentMedian);
    }
    System.out.println(this.robot.getLastHistoryEvent().getTimeStamp().toString());
    System.out.println(this.robot.getLastHistoryEvent().getSignal());
    if(memory.size()==NXTRpi.memorySize){
		int hot = 0;
		int cold = 0;
		for(int i=1; i<NXTRpi.memorySize; i++){
			if(memory.get(i-1).getSignal()<memory.get(i).getSignal()){
				hot++;
			}else if(memory.get(i-1).getSignal()>memory.get(i).getSignal()){
				cold++;
			}
		}
		Sound.beep();
		if(hot>=cold){
		//report OK
			robot.setDirectionOK(true);
			//System.out.println("Direction is OK");
		}else{
			//report notOK
			robot.setDirectionOK(false);
			System.out.println("Direction is not OK");
			robot.writeToLog("Direction not OK!");
		}
		memory.clear();
	}
  }
  
  public synchronized void dispatchNewSamples(DataCollection collection)
  {
    this.samplesRecieved = new DataCollection(collection.getSampleCollection());
    
    this.suspended = false;
    notify();
  }
  
  public void exitThread()
  {
    this.exit = true;
  }
}
