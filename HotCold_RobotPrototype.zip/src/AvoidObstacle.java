import lejos.robotics.subsumption.Behavior;

public class AvoidObstacle implements Behavior {

	@SuppressWarnings("unused")
	private boolean suppress;
	private NXTRpi robot;

	public AvoidObstacle(NXTRpi r){
		robot = r;
		suppress = false;
	}
	
	@Override
	public boolean takeControl() {
		return ( 
				(robot.getLeftUltra().getDistance() < NXTRpi.MinimumDistanceToAvoid) ||
				(robot.getRightUltra().getDistance() < NXTRpi.MinimumDistanceToAvoid)
			   );
	}

	@Override
	public void action() {
		suppress = false;
		System.out.println("Object Detected...Turning!");
		robot.setMoveType(MovementType.AVOID);
		/*
		if(direction<5){
			robot.getPilot().rotate(-20);
		}else{
			robot.getPilot().rotate(20);
		}
		
		// TL: the following lines try to maintain direction while following a wall (not turn erroneously back)
		robot.getPilot().travel(-10, false);
		System.out.println("Back");
		robot.getPilot().rotate(robot.getRotationDirection()*45, false); // turn the same direction with last random rotation
		System.out.println("1st turn");
		if ((robot.getUltra().getDistance() < NXTRpi.MinimumDistanceToAvoid + 10) && !suppress){
			robot.getPilot().rotate(robot.getRotationDirection()*45, false); // still obstacle: turn the same direction with last random rotation
			System.out.println("2nd turn");
			if ((robot.getUltra().getDistance() < NXTRpi.MinimumDistanceToAvoid + 15) && !suppress){ 
				robot.getPilot().rotate(-robot.getRotationDirection()*135, false); // still obstacle: turn the opposite direction with last random rotation
				System.out.println("3rd turn");
			}
		}*/
		
		// KD: avoiding with two sensors
		if(
			(robot.getLeftUltra().getDistance() < NXTRpi.MinimumDistanceToAvoid) &&
			(robot.getRightUltra().getDistance() >= NXTRpi.MinimumDistanceToAvoid)
		  )			
		{
			robot.getPilot().rotate(10);
		}else if(
				(robot.getLeftUltra().getDistance() >= NXTRpi.MinimumDistanceToAvoid) &&
				(robot.getRightUltra().getDistance() < NXTRpi.MinimumDistanceToAvoid)
				){
			robot.getPilot().rotate(-10);
		}else{
			robot.getPilot().rotate(180);
		}
	}

	@Override
	public void suppress() {
		suppress = true;
	}
}