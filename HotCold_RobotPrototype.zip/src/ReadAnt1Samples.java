

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

public class ReadAnt1Samples extends Thread{
	
	private SensorTimeRSSI reader;	
	private ArrayList<Data> sampleCollection;
	private SampleAnalyser sa;
	private boolean exit;
	private NXTRpi robot;
	
	ReadAnt1Samples(NXTRpi r, SampleAnalyser sa){
		sampleCollection = new ArrayList<Data>();
		this.sa = sa;
		exit = false;
		reader = new SensorTimeRSSI(NXTRpi.RSSIFilepath);
		robot = r;
	}
	
	public void run(){
		while(!exit){
			try {
				reader.update();
			} catch (IOException e1) {
				System.out.println("ex ReadAnt1Samples line 30");
				e1.printStackTrace();
			} catch (ParseException e1) {
				System.out.println("ex ReadAnt1Samples line 34");
				e1.printStackTrace();	
			}
			Data d = new Data(reader.getRSSI(), reader.getTimeDate(), robot.getCurrentMovement());
			packageNewSample(d);
		//	System.out.println("Sample received: "+d.toString());
			try {
				Thread.sleep(NXTRpi.ThreadUpdateTimeInMilis);
			} catch (InterruptedException e) {
				System.out.println("ex ReadAnt1Samples line 44");
				e.printStackTrace();				
			}
		}
	}
	
	public synchronized void packageNewSample(Data d){
		MovementType currentMoveType = d.getMoveType();
		if(currentMoveType==MovementType.DRIVE_FRW || currentMoveType==MovementType.STOP || currentMoveType==MovementType.TOWARDS_IR){
			if(sampleCollection.isEmpty()){
				sampleCollection.add(d);
			}else{
				if(d.getTimeStamp()!=sampleCollection.get(sampleCollection.size()-1).getTimeStamp()){
					sampleCollection.add(d);
					if(sampleCollection.size()==NXTRpi.sampleSize){
						sa.dispatchNewSamples(new DataCollection(sampleCollection));
						if(NXTRpi.IsSlidingWindow){
							sampleCollection.remove(0);
						} else {
						sampleCollection.clear();
						}
					}
				}
			}
		}else{
			sampleCollection.clear();
		}
	}	
	
	public void exitThread(){
		exit = true;
	}
}