import java.util.Date;

import lejos.robotics.subsumption.Behavior;

public class StopMoving
  implements Behavior
{
  private boolean suppress;
  private NXTRpi robot;
  
  public StopMoving(NXTRpi r)
  {
    this.robot = r;
    this.suppress = false;
  }
  
  public boolean takeControl()
  {
    Data d = this.robot.getLastHistoryEvent();
    if (d == null) {
      return false;
    }
    return d.getSignal() > NXTRpi.stoppingThreshold;
  }
  
  public void action()
  {
    this.suppress = false;
    System.out.println("Stop!");
    long timeElapsed = new Date().getTime() - robot.timeStarted;
    robot.writeToLog("Total time of run = "+timeElapsed);
    try
    {
      System.out.println(this.robot.getLastHistoryEvent().getTimeStamp().toString());
      System.out.println(this.robot.getLastHistoryEvent().getSignal());
    }
    catch (NullPointerException e)
    {
      System.out.println("Nothing in history yet");
    }
    this.robot.setMoveType(MovementType.STOP);
    this.robot.getPilot().stop();
  }
  
  public void suppress()
  {
    this.suppress = true;
  }
}
