import lejos.robotics.subsumption.Behavior;

public class DriveForward implements Behavior {

	@SuppressWarnings("unused")
	private boolean suppress;
	private NXTRpi robot;

	public DriveForward(NXTRpi r){
		robot = r;
		suppress = false;
	}
	
	@Override
	public boolean takeControl() {
		return !robot.getPilot().isMoving(); // TL
	}

	@Override
	public void action() {

		suppress = false;
		/*try {
		System.out.println(robot.getLastHistoryEvent().getTimeStamp().toString());
		} catch (NullPointerException e){
			System.out.println("No timestamp in history yet");
		}*/

		System.out.println("*");
		
		//if (!robot.getCurrentMovement().equals(MovementType.DRIVE_FRW))
		if (!robot.getPilot().isMoving() && !suppress) // TL
		{
			System.out.println("Driving FRW");
			robot.setMoveType(MovementType.DRIVE_FRW);
			robot.getPilot().forward();
		}
		
		/* NEW LINES BEGIN
		while(!suppress){
			Thread.yield();
		}
		robot.getPilot().stop();
		NEW LINES END */
		
		//Motor.B.forward();
		/*try {
		System.out.println(robot.getLastHistoryEvent().getSignal());
		} catch (NullPointerException e){
			System.out.println("No RSSI in history yet");
		}
		System.out.println("**");*/

	}

	@Override
	public void suppress() {
		suppress = true;
	}
}
