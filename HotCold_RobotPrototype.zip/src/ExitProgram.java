import lejos.robotics.subsumption.Behavior;

public class ExitProgram implements Behavior {

	@SuppressWarnings("unused")
	private boolean suppress = false;
	private NXTRpi robot;
	
	public ExitProgram(NXTRpi r) {
		super();
		robot = r;
	}

	@Override
	public boolean takeControl() {
		return  robot.getTouch().isPressed();
	}

	@Override
	public void action() {
		suppress = false;
		//NXTAntRobot.dropObject();
		robot.exitProgram();
	}

	@Override
	public void suppress() {
		suppress = true;
	}

}
