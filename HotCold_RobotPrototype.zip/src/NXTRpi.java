import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;

import lejos.nxt.Motor;
import lejos.nxt.SensorPort;
import lejos.nxt.TouchSensor;
import lejos.nxt.UltrasonicSensor;
import lejos.nxt.addon.CompassHTSensor;
import lejos.nxt.addon.IRSeekerV2;
import lejos.nxt.addon.IRSeekerV2.Mode;
import lejos.robotics.navigation.CompassPilot;
import lejos.robotics.navigation.DifferentialPilot;
import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;
import java.util.Date;


public class NXTRpi
{
  public long timeStarted;
  public static int memorySize; //= 3;
  public static int sampleSize; // = 3;
  public static long ThreadUpdateTimeInMilis; // = 500L;
  public static int stoppingThreshold; // = -50;
  public static int fastSpeed; // = 25;
  public static int slowSpeed; // = 15;
  public static int fastRotationSpeed; // = 120;
  public static int slowRotationSpeed; // = 60;
  public static int MinimumDistanceToAvoid; // = 25;
  public static String RSSIFilepath; // = "D:\\temp\\index.php";
  public static String LogFilepath; // = "D:\\temp\\log.txt";
  public static boolean IsSlidingWindow; // = false;
  public static int rotationAngle; // = 137;
  private TouchSensor touch;
  private CompassHTSensor compass;
  private UltrasonicSensor ultraLeft;
  private UltrasonicSensor ultraRight;
  private CompassPilot pilot;
  private Behavior[] array;
  private static Arbitrator arby;
  private boolean directionOK;
  private MovementType currentMovement;
  private ArrayList<Data> history;
  private File outputFile;
  private PrintWriter filePrinter;
  private Integer rotationDirection;
  private SampleAnalyser analyserThread;
  private ReadAnt1Samples sampleCollectorThread;
  private ReadConsoleScanner consoleReaderThread;
  
  public NXTRpi()
  {
    this.touch = new TouchSensor(SensorPort.S1);
    this.compass = new CompassHTSensor(SensorPort.S2);
    this.ultraLeft = new UltrasonicSensor(SensorPort.S3);    
    this.ultraRight = new UltrasonicSensor(SensorPort.S4);
    this.history = new ArrayList();
    
    //this.pilot = new DifferentialPilot(5.2D, 12.6D, Motor.B, Motor.C, false);
    this.pilot = new CompassPilot(compass, 8, (float) 17.5, Motor.B, Motor.C, true);
    this.pilot.setTravelSpeed(NXTRpi.fastSpeed);
    this.pilot.setRotateSpeed(NXTRpi.fastRotationSpeed);
    this.directionOK = true;
    this.rotationDirection = Integer.valueOf(1);
    
    this.array = new Behavior[5];
    this.array[0] = new DriveForward(this);
    this.array[1] = new RotateRandomly(this);
    this.array[2] = new AvoidObstacle(this);
    this.array[3] = new StopMoving(this);
    this.array[4] = new ExitProgram(this);
    arby = new Arbitrator(this.array);
    this.currentMovement = MovementType.INIT;
    
    this.outputFile = new File(NXTRpi.LogFilepath);
    try
    {
      this.filePrinter = new PrintWriter(this.outputFile);
    }
    catch (FileNotFoundException e)
    {
      e.printStackTrace();
      System.out.println("ex NXTRpi line 70");
    }
    this.analyserThread = new SampleAnalyser(this);
    this.sampleCollectorThread = new ReadAnt1Samples(this, this.analyserThread);
    this.consoleReaderThread = new ReadConsoleScanner(this);
    this.analyserThread.start();
    this.sampleCollectorThread.start();
    this.consoleReaderThread.start();
  }
  
  public UltrasonicSensor getLeftUltra()
  {
    return this.ultraLeft;
  }
  
  public UltrasonicSensor getRightUltra()
  {
    return this.ultraRight;
  }
  
  public TouchSensor getTouch()
  {
    return this.touch;
  }
  
  public DifferentialPilot getPilot()
  {
    return this.pilot;
  }
  
  public void setDirectionOK(boolean directionOK)
  {
    this.directionOK = directionOK;
  }
  
  public boolean isDirectionOK()
  {
    return this.directionOK;
  }
  
  public void start()
  {
    arby.start();
  }
  
  public void setMoveType(MovementType mt)
  {
    this.currentMovement = mt;
  }
  
  public MovementType getCurrentMovement()
  {
    return this.currentMovement;
  }
  
  public void exitProgram()
  {
    this.sampleCollectorThread.exitThread();
    this.analyserThread.exitThread();
    this.pilot.stop();
    this.filePrinter.close();
    System.out.println("Program Terminated");
    System.exit(0);
  }
  
  public void updateHistory(Data d)
  {
    this.history.add(d);
    this.filePrinter.print(d.toString());
    this.filePrinter.println();
    this.filePrinter.flush();
  }
  
  public Integer getRotationDirection()
  {
    return this.rotationDirection;
  }
  
  public void setRotationDirection(Integer rotationDirection)
  {
    this.rotationDirection = rotationDirection;
  }
  
  public Data getLastHistoryEvent()
  {
    if (this.history.isEmpty()) {
      return null;
    }
    return (Data)this.history.get(this.history.size() - 1);
  }
  
  public void writeToLog(String s){
		filePrinter.print(s);
		filePrinter.println();
		filePrinter.flush();
	}
  
  public static void main(String[] args)
  {
	NXTRpi.memorySize = Integer.parseInt(args[0]);  
	NXTRpi.sampleSize = Integer.parseInt(args[1]);
	NXTRpi.ThreadUpdateTimeInMilis = Long.parseLong(args[2]);
	NXTRpi.stoppingThreshold = Integer.parseInt(args[3]);
	NXTRpi.fastSpeed = Integer.parseInt(args[4]);
	NXTRpi.slowSpeed = Integer.parseInt(args[5]);
	NXTRpi.fastRotationSpeed = Integer.parseInt(args[6]);
	NXTRpi.slowRotationSpeed = Integer.parseInt(args[7]);
	NXTRpi.MinimumDistanceToAvoid = Integer.parseInt(args[8]);
	NXTRpi.RSSIFilepath = args[9];
	NXTRpi.LogFilepath = args[10];
	NXTRpi.IsSlidingWindow = Boolean.parseBoolean(args[11]);
	NXTRpi.rotationAngle = Integer.parseInt(args[12]);
	
	NXTRpi robo = new NXTRpi();
	robo.timeStarted  = new Date().getTime();
    robo.start();
  }

}
